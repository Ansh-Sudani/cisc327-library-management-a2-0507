import pytest
from library_service import search_books_in_catalog

def test_search_not_implemented():
    results = search_books_in_catalog("Harry", "title")
    assert results == []
